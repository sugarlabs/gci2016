# Copyright 2009 Simon Schampijer
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

"""HelloWorld Activity: A case study for developing an activity."""

from gi.repository import Gtk
import logging

import serial
import time

from gettext import gettext as _

from sugar3.activity import activity
from sugar3.graphics.toolbarbox import ToolbarBox
from sugar3.activity.widgets import ActivityButton
from sugar3.activity.widgets import TitleEntry
from sugar3.activity.widgets import StopButton
from sugar3.activity.widgets import ShareButton
from sugar3.activity.widgets import DescriptionItem

class arduGoActivity(activity.Activity):
    """HelloWorldActivity class as specified in activity.info"""

    def __init__(self, handle):
        """Set up the HelloWorld activity."""
        activity.Activity.__init__(self, handle)

        # we do not have collaboration features
        # make the share option insensitive
        self.max_participants = 1

        # toolbar with the new toolbar redesign
        toolbar_box = ToolbarBox()

        activity_button = ActivityButton(self)
        toolbar_box.toolbar.insert(activity_button, 0)
        activity_button.show()
        
        separator = Gtk.SeparatorToolItem()
        separator.props.draw = False
        separator.set_expand(True)
        toolbar_box.toolbar.insert(separator, -1)
        separator.show()

        stop_button = StopButton(self)
        toolbar_box.toolbar.insert(stop_button, -1)
        stop_button.show()

        self.set_toolbar_box(toolbar_box)
        toolbar_box.show()

        # label with the text, make the string translatable
        button = Gtk.Button("Turn On")
        button.connect("clicked",self.flashButton)

        self.box0 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12)
        self.box1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=6)
        self.box2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=6)

        self.label1 = Gtk.Label(" Upload ArduGo.ino to your arduino board and try it out with the following buttons \n You can try with the built-in led pin number 13. \n WARNING: Make sure to use a resistor in series with LEDs", )

        self.box0.pack_start(self.label1, True, True, 0)
        self.box0.pack_start(self.box1, True, True, 0)
        self.box0.pack_start(self.box2, True, True, 0)

        self.box1.pack_start(Gtk.Label(''), True, False, 0)
        self.label2 = Gtk.Label("Pin:")
        self.box1.pack_start(self.label2, False, False, 0)
        self.entry = Gtk.Entry()
        self.entry.set_text("13")
        self.box1.pack_start(self.entry, False, False, 0)
        self.box1.pack_start(Gtk.Label(''), True, False, 0)

        self.button1 = Gtk.Button(label="Turn On")
        self.button1.connect("clicked", self.onButton)
        self.box2.pack_start(self.button1, True, True, 0)

        self.button2 = Gtk.Button(label="Turn Off")
        self.button2.connect("clicked", self.offButton)
        self.box2.pack_start(self.button2, True, True, 0)

        self.button3 = Gtk.Button(label="Flash")
        self.button3.connect("clicked", self.flashButton)
        self.box2.pack_start(self.button3, True, True, 0)

        self.set_canvas(self.box0)
        self.box0.show_all()

        self.ser = serial.Serial('/dev/ttyUSB0', 9600)

    def turnOff(self,pin):
        self.ser.write("\x01")
        self.ser.write(chr(pin))

    def turnOn(self,pin):
        self.ser.write("\x02")
        self.ser.write(chr(pin))

    def flash(self,pin):
        self.ser.write("\x03")
        self.ser.write(chr(pin))

    def offButton(self,button):
        self.turnOff(int(self.entry.get_text()))

    def onButton(self,button):
        self.turnOn(int(self.entry.get_text()))

    def flashButton(self,button):
        self.flash(int(self.entry.get_text()))
