# sugarlabs
"Hello Sugar Labs"
Repo for code-in contest
I am Ege from Turkey I am 14 years old and i am a freshman in high school I am trying to improve my english and coding.
The reason i joined this competition is to learn more and help others who dont know things about this.
