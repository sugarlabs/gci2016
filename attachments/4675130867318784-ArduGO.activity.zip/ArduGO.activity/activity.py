# Copyright 2009 Simon Schampijer
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
from gi.repository import Gtk
from gi.repository import Gdk
from gi.repository import GdkPixbuf
from gi.repository import GObject
from ConfigParser import SafeConfigParser
import logging
import random



import logging  
import pty

import shlex, subprocess
from threading import Thread
import os, sys
import shlex, subprocess    
from gettext import gettext as _

from sugar3.activity import activity
from sugar3.graphics.toolbarbox import ToolbarBox
from sugar3.activity.widgets import ActivityButton
from sugar3.activity.widgets import TitleEntry
from sugar3.activity.widgets import StopButton
from sugar3.activity.widgets import ShareButton
from sugar3.activity.widgets import DescriptionItem

from shutil import copyfile



class Ardugo(activity.Activity):
    def make(self,install):
        pid,fd = pty.fork()
        if pid==0:
            for i in range(2):
                self.install()

    def __init__(self, handle):
        activity.Activity.__init__(self, handle)

        # we do not have collaboration features
        # make the share option insensitive
        self.max_participants = 1

        # toolbar with the new toolbar redesign
        toolbar_box = ToolbarBox()

        activity_button = ActivityButton(self)
        toolbar_box.toolbar.insert(activity_button, 0)
        activity_button.show()

        title_entry = TitleEntry(self)
        toolbar_box.toolbar.insert(title_entry, -1)
        title_entry.show()

        share_button = ShareButton(self)
        toolbar_box.toolbar.insert(share_button, -1)
        share_button.show()
        
        separator = Gtk.SeparatorToolItem()
        separator.props.draw = False
        separator.set_expand(True)
        toolbar_box.toolbar.insert(separator, -1)
        separator.show()

        stop_button = StopButton(self)
        toolbar_box.toolbar.insert(stop_button, -1)
        stop_button.show()

        self.set_toolbar_box(toolbar_box)
        toolbar_box.show()
        self.scroll = Gtk.ScrolledWindow()
        self.scroll.set_policy(
            Gtk.PolicyType.AUTOMATIC,
            Gtk.PolicyType.AUTOMATIC)
        # Uso un widget principal para los problemas de resolucion x2..
        self.widget_principal = Gtk.EventBox()
        self.crear_menu()
        self.scroll.add(self.widget_principal)
        self.maximize()
       # self.modify_bg(Gtk.StateType.NORMAL, Gdk.color_parse("light blue"))
        self.widget_principal.modify_bg(Gtk.StateType.NORMAL, Gdk.color_parse("white"))

        self.set_canvas(self.scroll)
        self.scroll.show_all()


    def crear_menu(self):
        self.menu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        Logos = Gtk.Image()

        pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_size(
            'activity/inicio.svg', 1050,600)
        Logos.set_from_pixbuf(pixbuf)
        Install = Gtk.Button('Install Arduino')
        Install.modify_bg(Gtk.StateType.NORMAL, Gdk.color_parse("light blue"))
        Run = Gtk.Button('Run Arduino')
        Run.modify_bg(Gtk.StateType.NORMAL, Gdk.color_parse("light blue"))
        Arduino = Gtk.Button('What is Arduino')
        Arduino.modify_bg(Gtk.StateType.NORMAL, Gdk.color_parse("light blue"))
        Help = Gtk.Button('Help')
        Help.modify_bg(Gtk.StateType.NORMAL, Gdk.color_parse("light blue"))
        self.menu.add(Logos)
        self.menu.add(Install)
        self.menu.add(Run)
        self.menu.add(Arduino)
        self.menu.add(Help)


        # Diseno
        self.menu.pack_start(Logos,True,False,10)
        self.menu.pack_start(Install ,True, True, 10)
        self.menu.pack_start(Run, True, True, 10)
        self.menu.pack_start(Arduino, False, False, 5)
        self.menu.pack_start(Help, False, False, 5)
        Install.connect('clicked', self.widget_install)
        Arduino.connect('clicked', self.introduction)
        Run.connect('clicked', self.run)
        Help.connect('clicked', self.help)
        self.menu.show_all()
        self.widget_principal.add(self.menu)
        self.widget_principal.show_all()
    def limpiar_ventana(self):
        for widget in self.widget_principal.get_children():
            self.widget_principal.remove(widget)

    def entrar_a_menu(self, widget=None):
        if not self.menu:
            self.crear_menu()

        self.limpiar_ventana()
        self.widget_principal.add(self.menu)
        self.widget_principal.show_all()
    def introduction(self,Arduino):
        self.limpiar_ventana()

        parser = SafeConfigParser(allow_no_value=True)
        parser.read('config.txt')
        introduction = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        titulo = Gtk.Label('Introduction on Arduino Board')
        info = Gtk.TextView()
        info.set_wrap_mode(Gtk.WrapMode.WORD)
        info.set_editable(False)

        textbuffer = info.get_buffer()
        textbuffer.set_text(parser.get('introduction_arduino','intro'))

        quit = Gtk.Button('Exit')

        Arduino.connect('clicked', self.introduction)
        
        quit.connect('clicked', self.entrar_a_menu)

        introduction.pack_start(titulo, False, False, 0)
        introduction.pack_start(info, True, True, 10)
        introduction.pack_start(quit,  True, True, 10)

        self.widget_principal.add(introduction)
        self.show_all()

    def help(self,Help):
        self.limpiar_ventana()

        parser_help = SafeConfigParser(allow_no_value=True)
        parser_help.read('config.ini')
        helping = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        title = Gtk.Label('Help if you can not connect your arduino board')
        infor = Gtk.TextView()
        infor.set_wrap_mode(Gtk.WrapMode.WORD)
        infor.set_editable(False)

        textbuffer = infor.get_buffer()
        textbuffer.set_text(parser_help.get('help_arduino','help'))

        quiti = Gtk.Button('Exit')

        Help.connect('clicked', self.help)
        
        quiti.connect('clicked', self.entrar_a_menu)

        helping.pack_start(title, False, False, 0)
        helping.pack_start(infor, True, True, 10)
        helping.pack_start(quiti,  True, True, 10)

        self.widget_principal.add(helping)
        self.widget_principal.show_all()
    def widget_install(self,Help):
        self.limpiar_ventana()
        installing = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)


        label = Gtk.Label('Starting installation ... wait a moment please')

        exit = Gtk.Button('Exit')


        exit.connect('clicked', self.entrar_a_menu)

        installing.pack_start(label,  True, True, 10)

        installing.pack_start(exit,  True, True, 10)

        self.widget_principal.add(installing)
        self.widget_principal.show_all()

        self.install()



    def run_command(self, cmd):
        os.system(cmd)

    def install_paquete(self):
        paquete = "arduino-1.0.5-6.fc20.noarch"
        self.run_command("yum install -y " + paquete)
    def install_paquete2(self):
        paquete2 = "pyserial-2.7-1.fc20.noarch"
        self.run_command("yum install -y " + paquete2)
    def run(self,Arduino):
        self.run_command("arduino")  
    def install(self):
        self.install_paquete()
        self.install_paquete2()
        os._exit(os.EX_OK)
