var viewElement = document.getElementById("view");
var levelE = document.getElementById("level");
var exerciseEnumber = document.getElementById("exercise-number");
var exerciseEtext = document.getElementById("exercise-text");
var typeE = document.getElementById("type");
var contentE = document.getElementById("content");
var scoreE = document.getElementById("score");
var headerE = document.getElementById("viewHeader");
function init () {
    if(location.hash !== "") {
        openView(location.hash.replace("#", ""));
    }
}

function openView (type) {
    switch (type) {
        case "Add":
            location.href = "#Add";
            updateView(1, 1, "+", "0", "#D20058", false, "Add");        
        break;
        case "Subtract":
            location.href = "#Subtract";  
            updateView(1, 1, "-", "0", "#129CBB", false, "Subtract");       
        break;
        case "Multiply":
            location.href = "#Multiply";
            updateView(1, 1, "✕", "0", "#EA922D", false, "Multiply"); 
        break;
        case "Divide":
            location.href = "#Divide";
            updateView(1, 1, "÷", "0", "#4B8A22", false, "Divide"); 
        break;
        
    }
    console.log(type);
    viewElement.style.transform = "scale(1)";
}
// update current view
function updateView (exercise, level, type, score, color, content, title) {
    contentE.innerHTML = content || "Sorry, no content yet" ;
    if(exercise) exerciseEnumber.innerHTML = exercise;
    if(title) exerciseEtext.innerHTML = title;
    if(level) levelE.innerHTML = level;
    if(score) scoreE.innerHTML = score;
    if(type) typeE.innerHTML = type;
    if(color) headerE.style.background = color;   
}

function closeView () {
    location.hash = "";
    viewElement.style.transform = "scale(0)";
}