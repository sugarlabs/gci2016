#!/usr/bin/env python

from sugar3.activity import bundlebuilder

bundlebuilder.start()
